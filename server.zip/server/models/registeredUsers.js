const mongoose = require ("mongoose")

const registeredUsersSchema = new mongoose.Schema({
    firstname: {
        type: String,
        required: true,

    },
    lastname: {
        type: String,
        required: true,

    },
    username: {
        type: String,
        required: true,
        unique: true,
        

    },
    password: {
        type: String,
        required: true,

    },

})

registeredUsersSchema.statics.isUniqueUsername = async function(username){
    try{
        const user = await this.findOne({username})
        if(user) {return false}
        return true;
    }
    catch(error){
        console.log('username is not unique')
        console.log(error.message)
        return false
    }

    }


const RegisteredUsers = mongoose.model('RegisteredUsers', registeredUsersSchema)
module.exports = RegisteredUsers;