export function Header(props) {
  return (
    <div className="header">
      <span>{props.element1}</span>
      <span>{props.element2}</span>
    </div>
  );
}
