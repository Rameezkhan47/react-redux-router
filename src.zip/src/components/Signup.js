import { useSelector, useDispatch } from "react-redux";
import React, { useState } from "react";
import { signupActions } from "../store/index";
import { Input } from "./Input";
// import { credentials } from "../App";
import { Header } from "./Header";
import { Link, useNavigate } from "react-router-dom";
// import "bootstrap/dist/css/bootstrap.min.css";
// import { Form } from "react-bootstrap";
// import { Button } from "react-bootstrap";



export function Signup() {
  const navigate = useNavigate();
  const [firstname, setFirstname] = useState("");
  const [lastname, setLastname] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const dispatch = useDispatch();
  const users = useSelector((state) => state.signup.users);

  function onchange(e) {
    if (e.target.name === "firstname") {
      setFirstname(e.target.value);
    } else if (e.target.name === "lastname") {
      setLastname(e.target.value);
    } else if (e.target.name === "username") {
      setUsername(e.target.value);
    } else if (e.target.name === "password") {
      setPassword(e.target.value);
    }
  }
  const validator = users.find((user) => user.username === username);

  function signup(e) {
    e.preventDefault();
    console.log('validator is', validator)
    if (!validator){    dispatch(signupActions.signup({ firstname, lastname, username, password }));
    console.log('signup users are', users)

}
else(alert('username already exists'))
    // credentials.push({ firstname, lastname, username, password });
    //alert('New user created')
    setFirstname("");
    setLastname("");
    setUsername("");
    setPassword("");
    // console.log(credentials);
    navigate("/");
  }
  return (
    <>
         <Header
        element2={
          <Link to="/">
            <button>Login</button>
          </Link>
        }
      />
{/* <div className="card w-75 bootstrap-card" >
<Form onSubmit={signup} className="rounded p-4 p-sm-5" >
        <h1 className="heading"> Registeration Form </h1>
        <div className="form-group">
          <label className="mb-2">First Name</label>
          <input
            className="form-control mb-2"
            type="text"
            name="firstname"
            change={onchange}
            val={firstname}
          />
        </div>
        <div className="form-group">
          <label className="mb-2">Last Name</label>
          <input
            className="form-control mb-2"
            type="text"
            name="lastname"
            change={onchange}
            val={lastname}
          />
        </div>

        <div className="form-group">
          <label className="mb-2">Username</label>
          <input
            className="form-control mb-2"
            type="text"
            name="username"
            change={onchange}
            val={username}
          />
        </div>
        <div className="form-group">
          <label className="mb-2">Password</label>
          <input
            className="form-control mb-2"
            label="Password"
            type="password"
            name="password"
            change={onchange}
            val={password}
          />
        </div>
        <div className="button-div">
          <Button  type="submit" className="btn btn-primary mt-3">
            Signup
          </Button>


        </div>
      </Form>
</div> */}




 
      <div className="signin">
        <form className="card">
          <Input
            label="First Name"
            type="text"
            name="firstname"
            change={onchange}
            val={firstname}
          />
          <Input
            label="Second Name"
            type="text"
            name="lastname"
            change={onchange}
            val={lastname}
          />
          <Input
            label="UserName"
            type="text"
            name="username"
            change={onchange}
            val={username}
          />
          <Input
            label="Password"
            type="password"
            name="password"
            change={onchange}
            val={password}
          />
          <button onClick={signup}>Sign Up</button>
        </form>
      </div>
    </>
  );
}
