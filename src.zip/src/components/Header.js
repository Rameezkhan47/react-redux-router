
export function Header(props) {
  
    return (
      <div className="header">
        <span >{props.element2}</span>
      </div>
    );
  
  }